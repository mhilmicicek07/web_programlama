
// Tarayıcı Depolama Alanları


// Session Storage

// Local Storage